
package interfaces;

public class Inicializador {
    
    public static void main(String[] args) {
        Ventana ventana = new Ventana();
    }
}
