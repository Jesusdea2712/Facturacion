
package interfaces;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class Ventana extends JFrame implements ActionListener{
    
    /* Definimos variables. */
    private final JMenuBar menuBar;
    private final JMenu registrar;
    private final JMenu consultar;
    private final JMenuItem usuarios;
    private final JMenuItem clientes;
    private final JMenuItem categorias;
    private final JMenuItem unidadMedida;
    private final JMenuItem producto;
    
    private final RegistroUsuario registroUsuario;
    private final RegistroClientes registroClientes;
    private final RegistroCategoria registroCategoria;
    private final RegistroUnidadMedida registroUnidadMedida;
    private final RegistroProducto registroProducto;

    
    public Ventana(){
        super("Modulo facturacion");
        setLayout(null);
        
        menuBar = new JMenuBar();
        registroUsuario = new RegistroUsuario();
        registroClientes = new RegistroClientes();
        registroCategoria = new RegistroCategoria();
        registroUnidadMedida = new RegistroUnidadMedida();
        registroProducto = new RegistroProducto();
        
        registrar = new JMenu("Registrar");
        consultar = new JMenu("Consultar");
        menuBar.add(registrar);
        menuBar.add(consultar);
        
        usuarios = new JMenuItem("Usuario");
        clientes = new JMenuItem("Cliente");
        categorias = new JMenuItem("Categoria");
        unidadMedida = new JMenuItem("Unidad de Medida");
        producto = new JMenuItem("Producto");
        registrar.add(usuarios);
        registrar.add(clientes);
        registrar.add(categorias);
        registrar.add(unidadMedida);
        registrar.add(producto);
        
        setJMenuBar(menuBar);
        //setContentPane(registroUsuario);
        setSize(650, 400);
        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        usuarios.addActionListener(this);
        clientes.addActionListener(this);
        categorias.addActionListener(this);
        unidadMedida.addActionListener(this);
        producto.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object objetoEvento = e.getSource();
        
        if(objetoEvento.equals(usuarios)){
            System.out.println("Usuarios");
            remove(getContentPane());
            setContentPane(registroUsuario);
            validate();
        }else if(objetoEvento.equals(clientes)){
            System.out.println("Clientes");
            remove(getContentPane());
            setContentPane(registroClientes);
            validate();
        }else if(objetoEvento.equals(categorias)){
            System.out.println("Categorias");
            remove(getContentPane());
            setContentPane(registroCategoria);
            validate();
        }else if(objetoEvento.equals(unidadMedida)){
            System.out.println("Unidades de medida");
            remove(getContentPane());
            setContentPane(registroUnidadMedida);
            validate();
        }else if(objetoEvento.equals(producto)){
            System.out.println("Productos");
            remove(getContentPane());
            setContentPane(registroProducto);
            validate();
        }
                
    }
    
}
