package domain;

import java.sql.Blob;

public class Producto {
    
    private int idProducto;
    private String nombre;;
    private double precioUnitario;
    private Blob foto;
    private double stock;
    private int idUnidadMedida;
    private int idCategoria;

    public Producto() {
    }

    public Producto(int idProducto) {
        this.idProducto = idProducto;
    }

    public Producto(String nombre, double precioUnitario, Blob foto, double stock) {
        this.nombre = nombre;
        this.precioUnitario = precioUnitario;
        this.foto = foto;
        this.stock = stock;
    }

    public Producto(int idProducto, String nombre, double precioUnitario, Blob foto, double stock, int idUnidadMedida, int idCategoria) {
        this.idProducto = idProducto;
        this.nombre = nombre;
        this.precioUnitario = precioUnitario;
        this.foto = foto;
        this.stock = stock;
        this.idUnidadMedida = idUnidadMedida;
        this.idCategoria = idCategoria;
    }
   
    

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }


    public Blob getFoto() {
        return foto;
    }

    public void setFoto(Blob foto) {
        this.foto = foto;
    }

    public double getStock() {
        return stock;
    }

    public void setStock(double stock) {
        this.stock = stock;
    }

    public int getIdUnidadMedida() {
        return idUnidadMedida;
    }

    public void setIdUnidadMedida(int idUnidadMedida) {
        this.idUnidadMedida = idUnidadMedida;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    @Override
    public String toString() {
        return "Producto{" + "idProducto=" + idProducto + ", nombre=" + nombre + ", precioUnitario=" + precioUnitario + ", foto=" + foto + ", stock=" + stock + ", idUnidadMedida=" + idUnidadMedida + ", idCategoria=" + idCategoria + '}';
    }

    
}
