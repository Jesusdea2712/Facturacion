package domain;

import java.sql.Date;


public class Venta {
    
    private int idVenta;
    private String tipoDocumento;
    private Date fecha;
    private int idCliente;

    public Venta(int idVenta, String tipoDocumento, Date fecha, int idCliente) {
        this.idVenta = idVenta;
        this.tipoDocumento = tipoDocumento;
        this.fecha = fecha;
        this.idCliente = idCliente;
    }

    

    public Venta(String tipoDocumento, Date fecha, int idCliente) {
        this.tipoDocumento = tipoDocumento;
        this.fecha = fecha;
        this.idCliente = idCliente;
    }

    public Venta(int idVenta) {
        this.idVenta = idVenta;
    }


    public int getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    } 

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    @Override
    public String toString() {
        return "Venta{" + "idVenta=" + idVenta + ", tipoDocumento=" + tipoDocumento + ", fecha=" + fecha + ", idCliente=" + idCliente + '}';
    }
    
    
}
