package domain;

public class ProductoVentas {
    
    private int idProducto;
    private int idVenta;

    public ProductoVentas(int idProducto, int idVenta) {
        this.idProducto = idProducto;
        this.idVenta = idVenta;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public int getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    @Override
    public String toString() {
        return "ProductoVentas{" + "idProducto=" + idProducto + ", idVenta=" + idVenta + '}';
    }
    
    
}
