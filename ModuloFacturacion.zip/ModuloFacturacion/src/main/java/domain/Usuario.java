package domain;

import java.util.Objects;

public class Usuario {
    
    private int idUsuario;
    private String login;
    private String nombre;
    private String contrasena;
    private boolean estado;

    public Usuario() {
    }

    public Usuario(String login, String contrasena) {
        this.login = login;
        this.contrasena = contrasena;
    }
    
    //Eliminar
    public Usuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    //Insertar
    public Usuario(String login, String nombre, String contrasena, boolean estado) {
        this.login = login;
        this.nombre = nombre;
        this.contrasena = contrasena;
        this.estado = estado;
    }

    //Modificar
    public Usuario(int idUsuario, String login, String nombre, String contrasena, boolean estado) {
        this.idUsuario = idUsuario;
        this.login = login;
        this.nombre = nombre;
        this.contrasena = contrasena;
        this.estado = estado;
    }

    public int getIdUsuario() {
        return this.idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }
    
    
    public String getLogin() {
        return this.login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getContrasena() {
        return this.contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public boolean isEstado() {
        return this.estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Usuario{" + "login=" + login + ", nombre=" + nombre + ", contrasena=" + contrasena + ", estado=" + estado + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 19 * hash + Objects.hashCode(this.login);
        hash = 19 * hash + Objects.hashCode(this.contrasena);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Usuario other = (Usuario) obj;
        if (!Objects.equals(this.login, other.login)) {
            return false;
        }
        if (!Objects.equals(this.contrasena, other.contrasena)) {
            return false;
        }
        return true;
    }
    
    
    
}
