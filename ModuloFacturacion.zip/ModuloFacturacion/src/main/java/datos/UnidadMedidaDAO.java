package datos;

import domain.UnidadMedida;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UnidadMedidaDAO {
    
    private static final String SQL_SELECT = "SELECT idUnidadMedida, nombre FROM unidadmedida";
    private static final String SQL_INSERT = "INSERT INTO unidadmedida(nombre) VALUES (?)";
    private static final String SQL_UPDATE = "UPDATE unidadmedida SET  nombre = ? WHERE idUnidadMedida = ?";
    private static final String SQL_DELETE = "DELETE FROM unidadmedida WHERE idUnidadMedida = ? ";
    
    public List<UnidadMedida> seleccionar(){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        UnidadMedida unidadMedida;
        List<UnidadMedida> unidadMedidas = new ArrayList<>();
        
        try {
            connection = Conexion.getConnection();
            preparedStatement = connection.prepareStatement(SQL_SELECT);
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                int idCategoria = resultSet.getInt("idUnidadMedida");
                String nombre = resultSet.getString("nombre");
                
                unidadMedida = new UnidadMedida();
                unidadMedidas.add(unidadMedida);
            }
        } catch (SQLException ex) {
        }finally{
            try {
                Conexion.close(resultSet);
                Conexion.close(preparedStatement);
                Conexion.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(UnidadMedidaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return unidadMedidas;
    }
    
    public int registrar(UnidadMedida unidadMedida){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int registros = 0;
        
        try {
            connection = Conexion.getConnection();
            preparedStatement = connection.prepareStatement(SQL_INSERT);
            preparedStatement.setString(1, unidadMedida.getNombre());
            registros = preparedStatement.executeUpdate();
 
        } catch (SQLException ex) {
            Logger.getLogger(UnidadMedidaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                Conexion.close(preparedStatement);
                Conexion.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(UnidadMedidaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return registros;
    }
    
     public int actualizar(UnidadMedida unidadMedida){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int registros = 0;
        
        try {
            connection = Conexion.getConnection();
            preparedStatement = connection.prepareStatement(SQL_UPDATE);
            preparedStatement.setString(1, unidadMedida.getNombre());
            registros = preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(UnidadMedidaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                Conexion.close(preparedStatement);
                Conexion.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(UnidadMedidaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return registros;
    }
     
    public int eliminar(UnidadMedida unidadMedida){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int registros = 0;
        
        try {
            connection = Conexion.getConnection();
            preparedStatement = connection.prepareStatement(SQL_DELETE);
            preparedStatement.setInt(1, unidadMedida.getIdUnidadMedida());
            registros = preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(UnidadMedidaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                Conexion.close(preparedStatement);
                Conexion.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(UnidadMedidaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return registros;
    } 
    
}
