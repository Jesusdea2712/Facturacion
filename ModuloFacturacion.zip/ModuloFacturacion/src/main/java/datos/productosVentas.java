package datos;

import domain.ProductoVentas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class productosVentas {
    
    private static final String SQL_SELECT = "SELECT Producto_idProducto, Ventas_idVentas FROM producto_has_ventas";
    
    public List<ProductoVentas> seleccionar(){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        ProductoVentas productoVentas;
        List<ProductoVentas> ventasProductos = new ArrayList<>();
        
        try {
            connection = Conexion.getConnection();
            preparedStatement = connection.prepareStatement(SQL_SELECT);
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                int idProducto = resultSet.getInt("Producto_idProducto");
                int idVentas = resultSet.getInt("Ventas_idVentas");
                
                productoVentas = new ProductoVentas(idProducto, idVentas);
                ventasProductos.add(productoVentas);
            }
        } catch (SQLException ex) {
        }finally{
            try {
                Conexion.close(resultSet);
                Conexion.close(preparedStatement);
                Conexion.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(productosVentas.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return ventasProductos;
    }
   
    
}
