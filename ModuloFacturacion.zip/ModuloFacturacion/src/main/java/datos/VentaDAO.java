package datos;

import domain.Venta;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class VentaDAO {
    
    private static final String SQL_SELECT = "SELECT idVentas, tipoDocumento, fecha, Cliente_idCliente FROM ventas";
    private static final String SQL_INSERT = "INSERT INTO ventas(tipoDocumento, fecha, Cliente_idCliente) VALUES (?, ?, ?)";
    private static final String SQL_UPDATE = "UPDATE ventas SET tipoDocumento = ?, fecha = ?, Cliente_idCliente = ? WHERE idVentas = ?";
    private static final String SQL_DELETE = "DELETE FROM ventas WHERE idVentas = ? ";
    
    public List<Venta> seleccionar(){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        Venta venta;
        List<Venta> ventas = new ArrayList<>();
        
        try {
            connection = Conexion.getConnection();
            preparedStatement = connection.prepareStatement(SQL_SELECT);
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                int idVentas = resultSet.getInt("idVentas");
                String tipoDocumento = resultSet.getString("tipoDocumento");
                Date fecha = resultSet.getDate("fecha");
                int idCliente = resultSet.getInt("Cliente_idCliente");
                
                venta = new Venta(idVentas, tipoDocumento, fecha, idCliente);
                ventas.add(venta);
            }
        } catch (SQLException ex) {
        }finally{
            try {
                Conexion.close(resultSet);
                Conexion.close(preparedStatement);
                Conexion.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(VentaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return ventas;
    }
    
    public int registrar(Venta venta){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int registros = 0;
        
        try {
            connection = Conexion.getConnection();
            preparedStatement = connection.prepareStatement(SQL_INSERT);
            preparedStatement.setString(1, venta.getTipoDocumento());
            preparedStatement.setDate(2, venta.getFecha());
            preparedStatement.setInt(3, venta.getIdCliente());
            registros = preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(VentaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                Conexion.close(preparedStatement);
                Conexion.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(VentaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return registros;
    }
    
     public int actualizar(Venta venta){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int registros = 0;
        
        try {
            connection = Conexion.getConnection();
            preparedStatement = connection.prepareStatement(SQL_UPDATE);
            preparedStatement.setString(1, venta.getTipoDocumento());
            preparedStatement.setDate(2, venta.getFecha());
            preparedStatement.setInt(3, venta.getIdCliente());
            preparedStatement.setInt(4, venta.getIdVenta());
            registros = preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(VentaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                Conexion.close(preparedStatement);
                Conexion.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(VentaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return registros;
    }
     
    public int eliminar(Venta venta){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int registros = 0;
        
        try {
            connection = Conexion.getConnection();
            preparedStatement = connection.prepareStatement(SQL_DELETE);
            preparedStatement.setInt(1, venta.getIdVenta());
            registros = preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(VentaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                Conexion.close(preparedStatement);
                Conexion.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(VentaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return registros;
    } 
    
}
