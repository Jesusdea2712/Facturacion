package datos;

import domain.Producto;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ProductoDAO {
    
    private static final String SQL_SELECT = "SELECT idProducto, nombre, precioUnitario, stock, foto, UnidadMedida_idUnidadMedida1, Categoria_idCategoria FROM producto";
    private static final String SQL_INSERT = "INSERT INTO producto(nombre, precioUnitario, stock, foto, UnidadMedida_idUnidadMedida1, Categoria_idCategoria) VALUES (?, ?, ?, ?, ?, ?)";
    private static final String SQL_UPDATE = "UPDATE producto SET nombre = ?, precioUnitario = ?, stock = ?, foto = ?,UnidadMedida_idUnidadMedida1 = ?, Categoria_idCategoria = ?  WHERE idProducto = ?";
    private static final String SQL_DELETE = "DELETE FROM producto WHERE idProducto = ? ";
    
    public List<Producto> seleccionar(){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        Producto producto;
        List<Producto> productos = new ArrayList<>();
        
        try {
            connection = Conexion.getConnection();
            preparedStatement = connection.prepareStatement(SQL_SELECT);
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                int idProducto = resultSet.getInt("idProducto");
                String nombre = resultSet.getString("nombre");
                double precioUnitario = resultSet.getDouble("precioUnitario");
                double stock = resultSet.getDouble("stock");
                Blob foto = resultSet.getBlob("foto");
                int idUnidadMedida = resultSet.getInt("UnidadMedida_idUnidadMedida1");
                int idCategoria = resultSet.getInt("Categoria_idCategoria");
                
                producto = new Producto(idProducto, nombre, precioUnitario, foto, stock, idUnidadMedida, idCategoria);
                productos.add(producto);
            }
        } catch (SQLException ex) {
        }finally{
            try {
                Conexion.close(resultSet);
                Conexion.close(preparedStatement);
                Conexion.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(ProductoDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return productos;
    }
    
    public int registrar(Producto producto){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int registros = 0;
        
        try {
            connection = Conexion.getConnection();
            preparedStatement = connection.prepareStatement(SQL_INSERT);
            preparedStatement.setString(1, producto.getNombre());
            preparedStatement.setDouble(2, producto.getPrecioUnitario());
            preparedStatement.setDouble(3, producto.getStock());
            preparedStatement.setBlob(4, producto.getFoto());
            preparedStatement.setInt(5, producto.getIdUnidadMedida());
            preparedStatement.setInt(6, producto.getIdCategoria());
            registros = preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(ProductoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                Conexion.close(preparedStatement);
                Conexion.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(ProductoDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return registros;
    }
    
     public int actualizar(Producto producto){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int registros = 0;
        
        try {
            connection = Conexion.getConnection();
            preparedStatement = connection.prepareStatement(SQL_UPDATE);
            preparedStatement.setString(1, producto.getNombre());
            preparedStatement.setDouble(2, producto.getPrecioUnitario());
            preparedStatement.setDouble(3, producto.getStock());
            preparedStatement.setBlob(4, producto.getFoto());
            preparedStatement.setInt(5, producto.getIdUnidadMedida());
            preparedStatement.setInt(6, producto.getIdCategoria());
            preparedStatement.setInt(7, producto.getIdProducto());
            registros = preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(ProductoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                Conexion.close(preparedStatement);
                Conexion.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(ProductoDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return registros;
    }
     
    public int eliminar(Producto producto){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int registros = 0;
        
        try {
            connection = Conexion.getConnection();
            preparedStatement = connection.prepareStatement(SQL_DELETE);
            preparedStatement.setInt(1, producto.getIdProducto());
            registros = preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(ProductoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                Conexion.close(preparedStatement);
                Conexion.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(ProductoDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return registros;
    }
    
}
