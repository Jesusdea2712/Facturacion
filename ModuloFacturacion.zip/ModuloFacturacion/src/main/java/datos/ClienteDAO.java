package datos;

import domain.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ClienteDAO {
    
    private static final String SQL_SELECT = "SELECT idCliente, nombre, direccion, DNI, RUC, telefono, correo FROM cliente";
    private static final String SQL_INSERT = "INSERT INTO cliente(nombre, direccion, DNI, RUC, telefono, correo) VALUES (?, ?, ?, ?, ?, ?)";
    private static final String SQL_UPDATE = "UPDATE cliente SET nombre = ?, direccion = ?, DNI = ?, RUC = ?, telefono = ?, correo = ? WHERE idCliente = ?";
    private static final String SQL_DELETE = "DELETE FROM cliente WHERE idCliente = ? ";
    
    public List<Cliente> seleccionar(){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        Cliente cliente;
        List<Cliente> clientes = new ArrayList<>();
        
        try {
            connection = Conexion.getConnection();
            preparedStatement = connection.prepareStatement(SQL_SELECT);
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                int idCliente = resultSet.getInt("idUsuario");
                String nombre = resultSet.getString("nombre");
                String direccion = resultSet.getString("direccion");
                int DNI = resultSet.getInt("DNI");
                int RUC = resultSet.getInt("RUC");
                int telefono = resultSet.getInt("telefono");
                String correo = resultSet.getString("correo");
                
                cliente = new Cliente(idCliente, nombre, direccion, DNI, RUC, telefono, correo);
                clientes.add(cliente);
            }
        } catch (SQLException ex) {
        }finally{
            try {
                Conexion.close(resultSet);
                Conexion.close(preparedStatement);
                Conexion.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return clientes;
    }
    
    public int registrar(Cliente cliente){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int registros = 0;
        
        try {
            connection = Conexion.getConnection();
            preparedStatement = connection.prepareStatement(SQL_INSERT);
            preparedStatement.setString(1, cliente.getNombre());
            preparedStatement.setString(2, cliente.getDireccion());
            preparedStatement.setInt(3, cliente.getDNI());
            preparedStatement.setInt(4, cliente.getRUC());
            preparedStatement.setInt(5, cliente.getTelefono());
            preparedStatement.setString(6, cliente.getCorreo());
            registros = preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                Conexion.close(preparedStatement);
                Conexion.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return registros;
    }
    
     public int actualizar(Cliente cliente){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int registros = 0;
        
        try {
            connection = Conexion.getConnection();
            preparedStatement = connection.prepareStatement(SQL_UPDATE);
            preparedStatement.setString(1, cliente.getNombre());
            preparedStatement.setString(2, cliente.getDireccion());
            preparedStatement.setInt(3, cliente.getDNI());
            preparedStatement.setInt(4, cliente.getRUC());
            preparedStatement.setInt(5, cliente.getTelefono());
            preparedStatement.setString(6, cliente.getCorreo());
            preparedStatement.setInt(7, cliente.getIdCliente());
            registros = preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                Conexion.close(preparedStatement);
                Conexion.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return registros;
    }
     
    public int eliminar(Cliente cliente){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int registros = 0;
        
        try {
            connection = Conexion.getConnection();
            preparedStatement = connection.prepareStatement(SQL_DELETE);
            preparedStatement.setInt(1, cliente.getIdCliente());
            registros = preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                Conexion.close(preparedStatement);
                Conexion.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return registros;
    } 
    
}
