package datos;

import domain.Categoria;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CategoriaDAO {
    
    private static final String SQL_SELECT = "SELECT idCategoria, nombre, abreviatura FROM categoria";
    private static final String SQL_INSERT = "INSERT INTO categoria(nombre, abreviatura) VALUES (?, ?)";
    private static final String SQL_UPDATE = "UPDATE categoria SET  nombre = ?, abreviatura = ? WHERE idCategoria = ?";
    private static final String SQL_DELETE = "DELETE FROM categoria WHERE idCategoria = ? ";
    
    public List<Categoria> seleccionar(){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        Categoria categoria;
        List<Categoria> categorias = new ArrayList<>();
        
        try {
            connection = Conexion.getConnection();
            preparedStatement = connection.prepareStatement(SQL_SELECT);
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                int idCategoria = resultSet.getInt("idCategoria");
                String nombre = resultSet.getString("nombre");
                String abreviatura = resultSet.getString("abreviatura");
                
                categoria = new Categoria();
                categorias.add(categoria);
            }
        } catch (SQLException ex) {
        }finally{
            try {
                Conexion.close(resultSet);
                Conexion.close(preparedStatement);
                Conexion.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return categorias;
    }
    
    public int registrar(Categoria categoria){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int registros = 0;
        
        try {
            connection = Conexion.getConnection();
            preparedStatement = connection.prepareStatement(SQL_INSERT);
            preparedStatement.setString(1, categoria.getNombre());
            preparedStatement.setString(2, categoria.getAbreviatura());
            registros = preparedStatement.executeUpdate();
 
        } catch (SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                Conexion.close(preparedStatement);
                Conexion.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return registros;
    }
    
     public int actualizar(Categoria categoria){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int registros = 0;
        
        try {
            connection = Conexion.getConnection();
            preparedStatement = connection.prepareStatement(SQL_UPDATE);
            preparedStatement.setString(1, categoria.getNombre());
            preparedStatement.setString(2, categoria.getAbreviatura());
            registros = preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                Conexion.close(preparedStatement);
                Conexion.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return registros;
    }
     
    public int eliminar(Categoria categoria){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int registros = 0;
        
        try {
            connection = Conexion.getConnection();
            preparedStatement = connection.prepareStatement(SQL_DELETE);
            preparedStatement.setInt(1, categoria.getIdCategoria());
            registros = preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                Conexion.close(preparedStatement);
                Conexion.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return registros;
    } 
    
}
