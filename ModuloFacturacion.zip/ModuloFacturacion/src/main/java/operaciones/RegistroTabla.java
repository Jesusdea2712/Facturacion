package operaciones;

public class RegistroTabla {
    
}
