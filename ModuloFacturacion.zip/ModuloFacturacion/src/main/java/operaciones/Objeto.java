package operaciones;

import domain.Categoria;
import domain.Cliente;
import domain.Producto;
import domain.UnidadMedida;
import domain.Usuario;
import domain.Venta;

public class Objeto {
    
    private Categoria categoria;
    private Cliente cliente;
    private Producto producto;
    private UnidadMedida unidadMedida;
    private Usuario usuario;
    private Venta venta;

    public Objeto(Categoria categoria, Cliente cliente, Producto producto, UnidadMedida unidadMedida, Usuario usuario, Venta venta) {
        this.categoria = categoria;
        this.cliente = cliente;
        this.producto = producto;
        this.unidadMedida = unidadMedida;
        this.usuario = usuario;
        this.venta = venta;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public UnidadMedida getUnidadMedida() {
        return unidadMedida;
    }

    public void setUnidadMedida(UnidadMedida unidadMedida) {
        this.unidadMedida = unidadMedida;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Venta getVenta() {
        return venta;
    }

    public void setVenta(Venta venta) {
        this.venta = venta;
    }
    
    
}
