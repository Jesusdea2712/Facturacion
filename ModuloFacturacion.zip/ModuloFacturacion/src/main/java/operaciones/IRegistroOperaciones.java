package operaciones;

public interface IRegistroOperaciones {
    
    void registrarVenta();
    void registrarUnidadMedida();
    void registrarCategoria();
    void registrarProducto();
    void registrarCliente();
    
}
