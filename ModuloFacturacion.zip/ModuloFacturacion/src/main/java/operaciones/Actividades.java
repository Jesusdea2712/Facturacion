package operaciones;


public enum Actividades {
    INSERTAR,
    MODIFICAR,
    ELIMINAR;
}
