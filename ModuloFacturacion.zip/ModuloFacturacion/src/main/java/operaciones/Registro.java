package operaciones;

public class Registro implements IRegistroOperaciones{

    @Override
    public void registrarVenta() {
    }

    @Override
    public void registrarUnidadMedida() {
    }

    @Override
    public void registrarCategoria() {
    }

    @Override
    public void registrarProducto() {
    }

    @Override
    public void registrarCliente() {
    }
    
}
