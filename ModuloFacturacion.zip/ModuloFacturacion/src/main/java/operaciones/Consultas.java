package operaciones;

public class Consultas {
    
}
